/*
 Navicat Premium Data Transfer

 Source Server         : localhost_MonGoDB
 Source Server Type    : MongoDB
 Source Server Version : 40203
 Source Host           : localhost:27017
 Source Schema         : ultimate

 Target Server Type    : MongoDB
 Target Server Version : 40203
 File Encoding         : 65001

 Date: 03/08/2021 16:48:10
*/


// ----------------------------
// Collection structure for ultimate
// ----------------------------
db.getCollection("ultimate").drop();
db.createCollection("ultimate");

// ----------------------------
// Documents of ultimate
// ----------------------------
