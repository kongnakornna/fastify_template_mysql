# typescript
This repository contains an example TypeScript application that makes use of the typeorm package with MySQL database and Node.js.
