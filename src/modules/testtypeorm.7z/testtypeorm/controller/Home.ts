import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify'
export default async function Home(fastify: FastifyInstance) {
    /***************/
    fastify.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
        reply.send({
                        title: {
                                message: "Welcome to app Service!",
                                message_th: "app Service ยินดีตอนรับ!",
                                status: true,
                                status_int: 1,
                                code: 200,
                                version: "1.0.0",
                                author: 'kongnakornna@gmail.com',
                            }, 
                        body: { data: null,error: null,   }, 
                    },
                )
            })
 /***************/
}