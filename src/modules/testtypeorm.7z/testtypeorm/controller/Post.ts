import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify'
import { getManager } from "typeorm";
import * as crypto from 'crypto'
import { User } from '../../../modules/testtypeorm/entity/User'
import { Post } from '../../../modules/testtypeorm/entity/Post'
export default async function Post(fastify: FastifyInstance) {
    /***************/
    const newUser = new User
    const newPost = new Post
    fastify.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
          // get a post repository to perform operations with post
            const postRepository = getManager().getRepository(Post);

            // load a post by a given post id
            const posts = await postRepository.find();
        reply.send({
                        title: {
                                message: "function PostSaveAction!",
                                message_th: "function PostSaveAction!",
                                status: true,
                                status_int: 1,
                                code: 200,
                                version: "1.0.0",
                                author: 'kongnakornna@gmail.com',
                            }, 
                        body: { data: posts,error: null,   }, 
                    },
                )
            })
 /***************/
    fastify.post('/saveAllPosts', async (request: FastifyRequest, reply: FastifyReply) => {
            const userRepository = getManager().getRepository(User);
            const postRepository = getManager().getRepository(Post);
            let i;
            let newUsers:any = [];
            let  newUser:any = {};
            let  newPost:any = {};
            for(i=1; i<=6; i ++) {

                newUser = await userRepository.findOne({ 
                select: ["id"],
                    where: { id: i} 
                });

            console.log("hi", newUser);
                if(typeof newUser == "undefined") {
                    const newUsers = new User 
                } else  {
                        console.log("update");
                        newPost = await postRepository.findOne({ 
                        select: ["id","userId"],
                        where: { userId: i} 
                        })
                }

                newUser.name  = "naval find pankaj test"+i; 
                newPost.title = "naval asf pankaj add post title "+i;
                newUser.posts = [newPost];
                newUsers.push(newUser);		
            }
            await userRepository.save(newUsers);  
        reply.send({
                        title: {
                                message: "function PostSaveAction!",
                                message_th: "function PostSaveAction!",
                                status: true,
                                status_int: 1,
                                code: 200,
                                version: "1.0.0",
                                author: 'kongnakornna@gmail.com',
                            }, 
                        body: { data: null,error: null,   }, 
                    },
                )
            })
 /***************/
}

 