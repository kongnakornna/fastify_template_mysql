import { FastifyInstance, FastifyRequest, FastifyReply } from 'fastify'
import {getManager} from "typeorm";
import {Post} from "../entity/Post";
export default async function PostSaveAction(fastify: FastifyInstance) {
    /***************/
    fastify.post('/', async (request: FastifyRequest, reply: FastifyReply) => {
        // get a post repository to perform operations with post
        const postRepository = getManager().getRepository(Post);
        const body: any = request.body
        // create a real post object from post json object sent over http
        const newPost = postRepository.create(body);
        // save received post
        await postRepository.save(newPost);
        // return saved post back
        reply.send({
                        title: {
                                message: "function PostSaveAction!",
                                message_th: "function PostSaveAction!",
                                status: true,
                                status_int: 1,
                                code: 200,
                                version: "1.0.0",
                                author: 'kongnakornna@gmail.com',
                            }, 
                        body: { data: newPost,error: null,   }, 
                    },
                )
            })
 /***************/
}