export default {
  params: {
    properties: {
      userId: {
        type: 'integer'
      }
    }
  }
}